#Mymath

- Pacote simples de operações básicas da matemática para fins didáticos